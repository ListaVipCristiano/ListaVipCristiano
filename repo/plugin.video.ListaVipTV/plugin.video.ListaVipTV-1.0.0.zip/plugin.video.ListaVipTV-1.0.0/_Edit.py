import xbmcaddon
MainBase = 'https://pastebin.com/raw/AsTpcFP2'
addon = xbmcaddon.Addon('plugin.video.ListaVipTV')